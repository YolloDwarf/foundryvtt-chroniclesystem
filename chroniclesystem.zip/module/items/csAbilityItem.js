import {CSItem} from "./csItem.js";

export class CSAbilityItem extends CSItem {

}