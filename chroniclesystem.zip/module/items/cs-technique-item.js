import {CSItem} from "./csItem.js";

export class CSTechniqueItem extends CSItem {

}